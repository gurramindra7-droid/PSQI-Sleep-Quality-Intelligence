﻿import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Activity,
  ArrowLeft,
  ArrowRight,
  Check,
  Moon,
  Sun,
  Sparkles,
  Clock3,
  HeartPulse,
  ShieldCheck,
  RotateCcw,
} from "lucide-react";
import { QUESTIONS } from "./data/questions";
import type { QuestionDef } from "./data/questions";
import { scorePsqi } from "./scoring/psqiScoring";
import type { PsqiResponses, PsqiResult } from "./scoring/types";

type Answers = Record<string, string | number>;
type Screen = "intro" | "assessment" | "results";

const FREQUENCY_LABELS = [
  "Not during the past month",
  "Less than once a week",
  "Once or twice a week",
  "Three or more times a week",
];

function App() {
  const [screen, setScreen] = useState<Screen>("intro");
  const [dark, setDark] = useState(true);
  const [answers, setAnswers] = useState<Answers>({});
  const [step, setStep] = useState(0);
  const [error, setError] = useState("");
  const [result, setResult] = useState<PsqiResult | null>(null);

  const groups = useMemo(() => {
    const visible = QUESTIONS.filter((q) => {
      if (!q.showIf) return true;
      return q.showIf.anyOf.includes(
        Number(answers[q.showIf.questionId])
      );
    });

    return visible;
  }, [answers]);

  const question = groups[step];
  const progress = groups.length ? ((step + 1) / groups.length) * 100 : 0;

  function updateAnswer(id: string, value: string | number) {
    setAnswers((previous) => ({ ...previous, [id]: value }));
    setError("");
  }

  function isAnswered(q: QuestionDef) {
    const value = answers[q.id];
    if (q.id === "q5j") {
      return Boolean(
        String(answers.q5jComment ?? "").trim() &&
        answers.q5j !== undefined
      );
    }
    if (value === undefined || value === "") return !q.required;
    return true;
  }

  function next() {
    if (!question) return;

    if (question.required && !isAnswered(question)) {
      setError("Please answer this question before continuing.");
      return;
    }

    if (step < groups.length - 1) {
      setStep((current) => current + 1);
      setError("");
    } else {
      finishAssessment();
    }
  }

  function previous() {
    setStep((current) => Math.max(0, current - 1));
    setError("");
  }

  function finishAssessment() {
    const responses: PsqiResponses = {};

    for (const q of QUESTIONS) {
      const value = answers[q.id];
      if (value === undefined || value === "") continue;

      if (["q1", "q3"].includes(q.id)) {
        responses[q.id as "q1" | "q3"] = String(value);
      } else if (q.id === "q2" || q.id === "q4") {
        responses[q.id as "q2" | "q4"] = Number(value);
      } else if (q.id === "q5j") {
        responses.q5j = Number(value);
        responses.q5jComment = String(answers.q5jComment ?? "");
      } else {
        (responses as Record<string, unknown>)[q.id] = Number(value);
      }
    }

    const scored = scorePsqi(responses);
    setResult(scored);
    setScreen("results");
  }

  function restart() {
    setAnswers({});
    setStep(0);
    setResult(null);
    setError("");
    setScreen("intro");
  }

  function renderQuestion(q: QuestionDef) {
    const value = answers[q.id];

    if (q.inputType === "time") {
      return (
        <div className="input-shell">
          <Clock3 size={20} />
          <input
            type="time"
            value={String(value ?? "")}
            onChange={(e) => updateAnswer(q.id, e.target.value)}
            aria-label={q.text}
          />
        </div>
      );
    }

    if (["minutes", "hours"].includes(q.inputType)) {
      return (
        <div className="input-shell">
          <input
            type="number"
            min={q.validation?.min ?? 0}
            max={q.validation?.max}
            step={q.validation?.step ?? 1}
            value={value ?? ""}
            placeholder={q.inputType === "minutes" ? "e.g. 20" : "e.g. 7.5"}
            onChange={(e) =>
              updateAnswer(
                q.id,
                e.target.value === "" ? "" : Number(e.target.value)
              )
            }
            aria-label={q.text}
          />
          <span className="input-unit">{q.validation?.unit}</span>
        </div>
      );
    }

    if (q.inputType === "frequencyWithText") {
      return (
        <div className="answer-stack">
          <label className="field-label">
            {q.textLabel ?? "Describe the reason"}
          </label>
          <textarea
            rows={3}
            value={String(answers.q5jComment ?? "")}
            placeholder="Describe the other reason (optional)"
            onChange={(e) => updateAnswer("q5jComment", e.target.value)}
          />
          <div className="option-grid">
            {(q.options ?? []).map((option) => (
              <button
                type="button"
                key={option.value}
                className={`option-card ${Number(value) === option.value ? "selected" : ""}`}
                onClick={() => updateAnswer(q.id, option.value)}
              >
                <span>{option.label}</span>
                {Number(value) === option.value && <Check size={18} />}
              </button>
            ))}
          </div>
        </div>
      );
    }

    const options = q.options ?? FREQUENCY_LABELS.map((label, index) => ({
      label,
      value: index,
    }));

    return (
      <div className="option-grid">
        {options.map((option) => (
          <button
            type="button"
            key={option.value}
            className={`option-card ${Number(value) === option.value ? "selected" : ""}`}
            onClick={() => updateAnswer(q.id, option.value)}
          >
            <span>{option.label}</span>
            {Number(value) === option.value && <Check size={18} />}
          </button>
        ))}
      </div>
    );
  }

  return (
    <main className={`app ${dark ? "theme-dark" : "theme-light"}`}>
      <div className="ambient ambient-one" />
      <div className="ambient ambient-two" />

      <header className="topbar">
        <button className="brand" onClick={() => setScreen("intro")}>
          <span className="brand-mark"><Moon size={19} /></span>
          <span>PSQI<span className="brand-dot">.</span></span>
        </button>

        <div className="header-right">
          <span className="header-label">SLEEP QUALITY INTELLIGENCE</span>
          <button
            className="theme-toggle"
            onClick={() => setDark((current) => !current)}
            aria-label="Toggle colour theme"
            title="Toggle dark/light mode"
          >
            {dark ? <Sun size={18} /> : <Moon size={18} />}
          </button>
        </div>
      </header>

      <AnimatePresence mode="wait">
        {screen === "intro" && (
          <motion.section
            key="intro"
            className="intro page-shell"
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.5 }}
          >
            <div className="intro-copy">
              <div className="eyebrow">
                <span className="live-dot" />
                YOUR REST, UNDERSTOOD
              </div>

              <h1>
                Better sleep
                <br />
                begins with
                <br />
                <span className="gradient-text">understanding.</span>
              </h1>

              <p className="intro-description">
                Explore your sleep quality through a structured assessment
                based on the Pittsburgh Sleep Quality Index. Reflect on your
                sleep patterns over the past month.
              </p>

              <div className="intro-actions">
                <button className="primary-button" onClick={() => {
                  setStep(0);
                  setScreen("assessment");
                }}>
                  Begin assessment <ArrowRight size={18} />
                </button>
                <span className="duration"><Clock3 size={15} /> About 5–10 minutes</span>
              </div>

              <div className="trust-row">
                <span><ShieldCheck size={16} /> No account required</span>
                <span><Activity size={16} /> Structured scoring</span>
              </div>
            </div>

            <div className="orb-stage" aria-hidden="true">
              <div className="orb-grid" />
              <div className="orb-ring ring-one" />
              <div className="orb-ring ring-two" />
              <div className="orb-ring ring-three" />
              <motion.div
                className="sleep-orb"
                animate={{ rotate: 360, scale: [1, 1.035, 1] }}
                transition={{
                  rotate: { duration: 40, repeat: Infinity, ease: "linear" },
                  scale: { duration: 5, repeat: Infinity, ease: "easeInOut" },
                }}
              >
                <div className="orb-core" />
                <div className="orb-highlight" />
              </motion.div>
              <motion.div
                className="floating-chip chip-top"
                animate={{ y: [0, -9, 0] }}
                transition={{ duration: 4, repeat: Infinity }}
              >
                <Moon size={16} /> Sleep patterns
              </motion.div>
              <motion.div
                className="floating-chip chip-bottom"
                animate={{ y: [0, 8, 0] }}
                transition={{ duration: 5, repeat: Infinity }}
              >
                <HeartPulse size={16} /> Rest & recovery
              </motion.div>
              <div className="orb-caption">
                <Sparkles size={14} /> A clearer picture of your rest
              </div>
            </div>

            <div className="intro-footer">
              <span>01 / UNDERSTAND YOUR SLEEP</span>
              <span>AN INDEPENDENT DIGITAL IMPLEMENTATION</span>
            </div>
          </motion.section>
        )}

        {screen === "assessment" && question && (
          <motion.section
            key="assessment"
            className="assessment page-shell"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -15 }}
          >
            <div className="assessment-top">
              <button className="text-button" onClick={() => setScreen("intro")}>
                <ArrowLeft size={17} /> Exit assessment
              </button>
              <span className="step-count">
                QUESTION {String(step + 1).padStart(2, "0")} / {String(groups.length).padStart(2, "0")}
              </span>
            </div>

            <div className="progress-track">
              <motion.div
                className="progress-fill"
                animate={{ width: `${progress}%` }}
                transition={{ duration: 0.3 }}
              />
            </div>

            <div className="question-layout">
              <aside className="question-sidebar">
                <div className="sidebar-icon"><Moon size={22} /></div>
                <p className="eyebrow">THE PAST MONTH</p>
                <h2>Every detail helps build a clearer picture.</h2>
                <p className="sidebar-note">
                  Answer based on your usual experience during the past month.
                  There are no right or wrong personal experiences.
                </p>
                <div className="sidebar-progress">
                  <span>YOUR PROGRESS</span>
                  <strong>{Math.round(progress)}%</strong>
                </div>
              </aside>

              <div className="question-panel">
                <div className="question-number">QUESTION {question.number}</div>
                {question.stem && <p className="question-stem">{question.stem}</p>}
                <h1>{question.text}</h1>
                {question.hint && <p className="question-hint">{question.hint}</p>}
                <div className="answer-area">{renderQuestion(question)}</div>
                {error && <p className="error-message">{error}</p>}

                <div className="question-navigation">
                  <button
                    className="secondary-button"
                    onClick={previous}
                    disabled={step === 0}
                  >
                    <ArrowLeft size={17} /> Back
                  </button>
                  <button className="primary-button" onClick={next}>
                    {step === groups.length - 1 ? "View results" : "Continue"}
                    <ArrowRight size={17} />
                  </button>
                </div>
              </div>
            </div>

            <p className="privacy-note">
              <ShieldCheck size={14} /> Your answers stay in this browser session.
              This prototype does not send them to a server.
            </p>
          </motion.section>
        )}

        {screen === "results" && result && (
          <motion.section
            key="results"
            className="results page-shell"
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <div className="results-heading">
              <div className="eyebrow"><span className="live-dot" /> ASSESSMENT COMPLETE</div>
              <h1>Your sleep, <span className="gradient-text">at a glance.</span></h1>
              <p>Review the scores calculated from the answers you provided.</p>
            </div>

            <div className="score-hero">
              <div className="score-main">
                <span className="score-label">GLOBAL PSQI SCORE</span>
                <div className="score-value">
                  {result.total ?? "—"}<span> / 21</span>
                </div>
                <p>{result.interpretation.headline}</p>
              </div>
              <div className="score-status">
                <div className="score-icon"><Activity size={26} /></div>
                <span>SCORING STATUS</span>
                <strong>{result.status.toUpperCase()}</strong>
                <small>Based on the implemented scoring rules</small>
              </div>
            </div>

            <div className="section-heading">
              <div>
                <span className="eyebrow">THE BREAKDOWN</span>
                <h2>Seven component scores</h2>
              </div>
              <span className="max-score">Each component: 0–3</span>
            </div>

            <div className="component-grid">
              {result.components.map((component, index) => (
                <motion.article
                  className="component-card"
                  key={component.key}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.06 }}
                >
                  <div className="component-top">
                    <span className="component-index">{String(index + 1).padStart(2, "0")}</span>
                    <span className={`component-score ${component.score === null ? "missing-score" : ""}`}>
                      {component.score ?? "—"}<small> / 3</small>
                    </span>
                  </div>
                  <h3>{component.name}</h3>
                  <p>{component.rule}</p>
                  <div className="score-bars">
                    {[0, 1, 2].map((bar) => (
                      <span
                        key={bar}
                        className={component.score !== null && bar < component.score ? "bar-active" : ""}
                      />
                    ))}
                  </div>
                  <span className="component-status">{component.status}</span>
                </motion.article>
              ))}
            </div>

            <div className="interpretation-panel">
              <div className="interpretation-icon"><HeartPulse size={22} /></div>
              <div>
                <h3>Understanding your result</h3>
                <p>{result.interpretation.disclaimer}</p>
                <p className="source-rule">{result.interpretation.sourceRule}</p>
              </div>
            </div>

            {result.issues.length > 0 && (
              <div className="issues-panel">
                <h3>Items to review</h3>
                {result.issues.map((issue, index) => (
                  <p key={`${issue.code}-${index}`}>
                    <strong>{issue.severity.toUpperCase()}</strong> — {issue.message}
                  </p>
                ))}
              </div>
            )}

            <div className="results-actions">
              <button className="secondary-button" onClick={() => window.print()}>
                Print / Save as PDF
              </button>
              <button className="primary-button" onClick={restart}>
                <RotateCcw size={17} /> Start again
              </button>
            </div>

            <p className="medical-disclaimer">
              This digital implementation is for informational and educational use.
              It is not a diagnosis and does not replace advice from a qualified
              healthcare professional. Not an official or endorsed University of
              Pittsburgh product.
            </p>
          </motion.section>
        )}
      </AnimatePresence>

      <footer className="site-footer">
        <span>PSQI <span className="brand-dot">.</span> SLEEP QUALITY INTELLIGENCE</span>
        <span>INDEPENDENT DIGITAL IMPLEMENTATION</span>
      </footer>
    </main>
  );
}

export default App;
