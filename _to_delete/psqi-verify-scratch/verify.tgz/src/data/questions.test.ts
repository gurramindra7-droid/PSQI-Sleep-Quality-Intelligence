import { describe, it, expect } from 'vitest';
import { QUESTIONS, QUESTION_BY_ID, REQUIRED_IDS, STEPS, visibleQuestions } from './questions.ts';
import { REQUIRED_QUESTION_IDS } from '../scoring/psqiScoring.ts';
import { FREQUENCY_SCALE } from '../scoring/responseScales.ts';

describe('question configuration vs the supplied PDF and Exhibit A', () => {
  it('has unique ids', () => {
    expect(new Set(QUESTIONS.map((q) => q.id)).size).toBe(QUESTIONS.length);
  });

  it('has 26 items: Q1–Q4, Q5a–Q5j, Q6–Q9, Q10 and Q10a–Q10e', () => {
    expect(QUESTIONS.map((q) => q.number)).toEqual([
      '1', '2', '3', '4',
      '5a', '5b', '5c', '5d', '5e', '5f', '5g', '5h', '5i', '5j',
      '6', '7', '8', '9',
      '10', '10a', '10b', '10c', '10d', '10e',
    ]);
  });

  it('required items are exactly the ones the scoring engine requires (Q1–Q9, without Q5j)', () => {
    expect([...REQUIRED_IDS]).toEqual([...REQUIRED_QUESTION_IDS]);
  });

  it('every step lists only known questions, and every question is in exactly one step', () => {
    const seen: string[] = [];
    for (const s of STEPS) for (const id of s.questionIds) {
      expect(id in QUESTION_BY_ID).toBe(true);
      seen.push(id);
    }
    expect(seen.slice().sort()).toEqual(QUESTIONS.map((q) => q.id).sort());
  });

  it('every choice item offers four options valued 0–3 in order', () => {
    for (const q of QUESTIONS) {
      if (q.inputType === 'time' || q.inputType === 'minutes' || q.inputType === 'hours') continue;
      expect(q.options!.map((o) => o.value)).toEqual([0, 1, 2, 3]);
    }
  });

  it('frequency items use the printed frequency labels', () => {
    expect(FREQUENCY_SCALE.map((o) => o.label)).toEqual([
      'Not during the past month',
      'Less than once a week',
      'Once or twice a week',
      'Three or more times a week',
    ]);
    expect(QUESTION_BY_ID.q7.options).toEqual(FREQUENCY_SCALE);
  });

  it('only Q1–Q9 items are scored; Q10 items never are', () => {
    for (const q of QUESTIONS) expect(q.scored).toBe(!q.id.startsWith('q10'));
  });

  it('Q5j is optional but scored (documented exception)', () => {
    expect(QUESTION_BY_ID.q5j.required).toBe(false);
    expect(QUESTION_BY_ID.q5j.scored).toBe(true);
  });

  it('Q5a feeds latency; Q5b–Q5j feed disturbances', () => {
    expect(QUESTION_BY_ID.q5a.components).toEqual(['laten']);
    for (const l of 'bcdefghij') expect(QUESTION_BY_ID[`q5${l}`].components).toEqual(['distb']);
  });

  it('partner items appear only when a partner or room mate exists', () => {
    const ids = ['q10', 'q10a', 'q10e'];
    expect(visibleQuestions({}, ids).map((q) => q.id)).toEqual(['q10']);
    expect(visibleQuestions({ q10: 0 }, ids).map((q) => q.id)).toEqual(['q10']);
    expect(visibleQuestions({ q10: 1 }, ids).map((q) => q.id)).toEqual(['q10', 'q10a', 'q10e']);
    expect(visibleQuestions({ q10: 3 }, ids).map((q) => q.id)).toEqual(['q10', 'q10a', 'q10e']);
  });
});
